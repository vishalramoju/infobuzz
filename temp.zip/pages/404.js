export default function F404() {
  return <div>404</div>;
}
